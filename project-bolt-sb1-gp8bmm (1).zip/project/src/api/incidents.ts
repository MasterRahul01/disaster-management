import { Incident } from '../types';

export const incidentsApi = {
  reportIncident: async (incident: Omit<Incident, 'id' | 'status' | 'timestamp'>): Promise<Incident> => {
    const response = await fetch('/api/incidents', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(incident),
    });
    if (!response.ok) throw new Error('Failed to report incident');
    return response.json();
  },

  getActiveIncidents: async (): Promise<Incident[]> => {
    const response = await fetch('/api/incidents/active');
    if (!response.ok) throw new Error('Failed to fetch active incidents');
    return response.json();
  },

  updateIncidentStatus: async (
    id: string,
    status: Incident['status'],
    update?: { message: string }
  ): Promise<Incident> => {
    const response = await fetch(`/api/incidents/${id}/status`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status, update }),
    });
    if (!response.ok) throw new Error('Failed to update incident status');
    return response.json();
  },

  getIncidentsByArea: async (lat: number, lng: number, radius: number): Promise<Incident[]> => {
    const response = await fetch(`/api/incidents?lat=${lat}&lng=${lng}&radius=${radius}`);
    if (!response.ok) throw new Error('Failed to fetch incidents');
    return response.json();
  },
};