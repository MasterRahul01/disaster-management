import Incident from '../models/Incident.js';
import { catchAsync } from '../utils/catchAsync.js';

export const reportIncident = catchAsync(async (req, res) => {
  const incident = await Incident.create(req.body);
  res.status(201).json(incident);
});

export const getActiveIncidents = catchAsync(async (req, res) => {
  const incidents = await Incident.find({
    status: { $ne: 'resolved' }
  }).sort('-createdAt');
  
  res.status(200).json(incidents);
});

export const updateIncidentStatus = catchAsync(async (req, res) => {
  const { id } = req.params;
  const { status, update } = req.body;
  
  const incident = await Incident.findByIdAndUpdate(
    id,
    {
      status,
      $push: {
        updates: {
          message: update?.message,
          status,
          timestamp: new Date()
        }
      }
    },
    { new: true, runValidators: true }
  );
  
  if (!incident) {
    return res.status(404).json({ message: 'Incident not found' });
  }
  
  res.status(200).json(incident);
});

export const getIncidentsByArea = catchAsync(async (req, res) => {
  const { lat, lng, radius = 5000 } = req.query; // radius in meters
  
  const incidents = await Incident.find({
    'location.coordinates': {
      $near: {
        $geometry: {
          type: 'Point',
          coordinates: [parseFloat(lng), parseFloat(lat)]
        },
        $maxDistance: parseInt(radius)
      }
    }
  }).sort('-createdAt');
  
  res.status(200).json(incidents);
});